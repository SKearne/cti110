import turtle

# Draw a square
for i in range(4):
    turtle.forward(100)
    turtle.right(90)
turtle.penup()
turtle.forward(130)
turtle.pendown()

# Draw a triangle
sides = 0
while sides < 3:
    turtle.forward(100)
    turtle.right(120)
    sides += 1

