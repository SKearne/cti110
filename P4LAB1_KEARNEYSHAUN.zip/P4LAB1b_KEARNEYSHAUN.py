import turtle

turtle.pencolor("red")
turtle.pensize(5)
# Draw 'S'
turtle.penup()
turtle.goto(-100, 0) # Position for 'S'
turtle.pendown()


turtle.forward(40)
turtle.circle(50, 180)
turtle.circle(-50, 180)
turtle.forward(40)

# Draw 'K'
turtle.penup()
turtle.goto(20, 0) # Position for 'K'
turtle.pendown()
turtle.left(90)
turtle.forward(200)
turtle.backward(110)
turtle.right(45)
turtle.forward(145)
turtle.backward(145)
turtle.right(74)
turtle.forward(160)

turtle.done()
